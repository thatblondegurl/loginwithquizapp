package com.example.loginandquiz;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class MainActivity extends AppCompatActivity {

    // two buttons that will bring the user to the next page and the other one will bring the user to the home screen
    Button Cancel, Proceed;

    // text fields that ask user to input first name last name email and password. Pass word is required to be more than 9 letters

    EditText FirstName, LastName, Email, Password;

    // checks to see if all text boxes are checked.
    boolean isAllFieldsChecked = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // two buttons proceed and cancel one that will bring the user to the next page if inputs are correct
        Proceed = findViewById(R.id.proceedButton);
        Cancel = findViewById(R.id.cancelButton);

        // register all the EditText fields with their IDs.
        FirstName = findViewById(R.id.first);
        LastName = findViewById(R.id.last);
        Email = findViewById(R.id.email);
        Password = findViewById(R.id.password);

        // on click proceed button
        Proceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                // store the returned value of the dedicated function which checks
                // whether the entered data is valid or if any fields are left blank.
                isAllFieldsChecked = CheckAllFields();

                // if everything is filled correctly it will take the user to the next window
                if (isAllFieldsChecked) {
                    Intent i = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(i);
                }
            }
        });

        // if user presses the cancel button then close the applicaion/activity+
        Cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MainActivity.this.finish();
                System.exit(0);
            }
        });
    }

    // checks to see if all the requirements are filled by the user
    //if not the user will see a box that explains what they forgot
    private boolean CheckAllFields() {
        if (FirstName.length() == 0) {
            FirstName.setError("This field is required");
            return false;
        }

        if (LastName.length() == 0) {
            LastName.setError("This field is required");
            return false;
        }

        if (Email.length() == 0) {
            Email.setError("Email is required");
            return false;
        }

        if (Password.length() == 0) {
            Password.setError("Password is required");
            return false;
        } else if (Password.length() < 8) {
            Password.setError("Password must be minimum 8 characters");
            return false;
        }

        // after all validation return true.
        return true;
    }
}

